unshadow passwd shadow > ./unshadow
john --wordlist=abridged_rockyou.txt   unshadow
